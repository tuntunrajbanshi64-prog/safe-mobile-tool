function getLocation() {
  const output = document.getElementById("location");

  if (!navigator.geolocation) {
    output.textContent = "Location supported छैन।";
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      output.textContent =
        `Latitude: ${lat.toFixed(6)}, Longitude: ${lon.toFixed(6)}`;
    },
    () => {
      output.textContent = "Location permission दिइएन।";
    }
  );
}

async function openCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true
    });

    document.getElementById("camera").srcObject = stream;
  } catch (error) {
    alert("Camera permission दिइएन।");
  }
}